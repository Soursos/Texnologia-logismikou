package rebook.formsdata;


public class RecommendationsFormData {
    
    private String recommendationType;
   
    public String getRecommendationType() {
        return recommendationType;
    }

    public void setRecommendationType(String recommendationType) {
        this.recommendationType = recommendationType;
    }
}
