package rebook.recommendationstrategy;

import java.util.List;

import rebook.domainmodel.Book;
import rebook.domainmodel.SimpleReader;
import rebook.mappers.BookMapper;

public interface BookRecommendationStrategy {
    List<Book> recommendBooks(SimpleReader user, BookMapper bookMapper);
}