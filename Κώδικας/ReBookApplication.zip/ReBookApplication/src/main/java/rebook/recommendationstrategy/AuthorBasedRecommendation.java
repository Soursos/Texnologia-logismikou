package rebook.recommendationstrategy;

import java.util.List;
import java.util.stream.Collectors;

import rebook.domainmodel.Book;
import rebook.domainmodel.SimpleReader;
import rebook.mappers.BookMapper;

public class AuthorBasedRecommendation  implements BookRecommendationStrategy {
    
    @Override
    public List<Book> recommendBooks(SimpleReader user, BookMapper bookMapper) {
        return user.getFavouriteBookAuthors().stream()
                   .flatMap(author -> bookMapper.findByBookAuthorsContains(author).stream())
                   .distinct()
                   .collect(Collectors.toList());
    }
}
