package rebook.recommendationstrategy;

import java.util.List;
import java.util.stream.Collectors;

import rebook.domainmodel.Book;
import rebook.domainmodel.SimpleReader;
import rebook.mappers.BookMapper;

public class CategoryBasedRecommendation implements BookRecommendationStrategy {
    
	@Override
    public List<Book> recommendBooks(SimpleReader user,BookMapper bookMapper) {
        return user.getFavouriteBookCategories().stream()
                   .flatMap(category -> bookMapper.findByBookCategory(category).stream())
                   .distinct()
                   .collect(Collectors.toList());
    }
}
