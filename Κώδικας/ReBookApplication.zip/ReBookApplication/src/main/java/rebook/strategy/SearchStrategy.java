package rebook.strategy;


import java.util.List;

import rebook.formsdata.BookFormData;
import rebook.formsdata.SearchFormData;
import rebook.mappers.BookMapper;

public interface SearchStrategy {
    List<BookFormData> search(SearchFormData searchFormData, BookMapper bookMapper);
}
