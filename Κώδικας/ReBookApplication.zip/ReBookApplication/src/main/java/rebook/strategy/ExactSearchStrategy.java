package rebook.strategy;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import rebook.domainmodel.Book;
import rebook.formsdata.SearchFormData;
import rebook.mappers.BookMapper;

@Component
public class ExactSearchStrategy extends TemplateSearchStrategy {
	@Autowired
	private BookMapper bookMapper;
	
	protected List<Book> makeInitialListOfBooks(SearchFormData searchFormData){
		 List <Book> books = bookMapper.findByTitle(searchFormData.getTitle());
		 return books;
		
	 }
	 protected boolean checkIfAuthorsMatch(SearchFormData searchFormData, Book book) {
		 return searchFormData.getAuthorNames().isEmpty() || book.getBookAuthors().stream()
		            .allMatch(author -> searchFormData.getAuthorNames().contains(author.getAuthorName()));
	 }

}
