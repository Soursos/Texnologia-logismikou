package rebook.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import rebook.domainmodel.Role;
import rebook.domainmodel.User;
import rebook.formsdata.SimpleReaderFormData;
import rebook.services.SimpleReaderService;
import rebook.services.UserService;


@Controller
public class AuthController {
    @Autowired
    UserService userService;
    @Autowired
    SimpleReaderService userProfileService;
    
    @RequestMapping("/login")
    public String login(){
        return "auth/signin";
    }

    @RequestMapping("/register")
    public String register(Model model){
        model.addAttribute("user", new User());
        return "auth/signup";
    }

    @RequestMapping("/save")
    public String registerUser(@ModelAttribute("user") User user, Model model){
       
        if(userService.isUserPresent(user)){
            model.addAttribute("failedMessage", "User already registered!");
            return "auth/signin";
        }
        
        user.setRole(Role.USER);
        
        userService.saveUser(user);
        //UserProfile userProfile = new UserProfile();
        SimpleReaderFormData formData = new SimpleReaderFormData();
        formData.setUserId(user.getId());
        
		userProfileService.save(formData);
        
        model.addAttribute("successMessage", "User registered successfully!");

        return "auth/signin";
    }
}
