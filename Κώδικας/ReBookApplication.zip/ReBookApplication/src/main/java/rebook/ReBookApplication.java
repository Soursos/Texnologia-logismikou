package rebook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReBookApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(ReBookApplication.class, args);
	
	}

}
