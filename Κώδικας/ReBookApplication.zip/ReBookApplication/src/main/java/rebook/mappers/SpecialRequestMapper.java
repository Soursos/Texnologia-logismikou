package rebook.mappers;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import rebook.domainmodel.Book;
import rebook.domainmodel.BookAuthor;
import rebook.domainmodel.BookCategory;
import rebook.domainmodel.SimpleReader;
import rebook.domainmodel.SpecialRequest;

import java.util.List;

@Repository
public interface SpecialRequestMapper extends JpaRepository<Book, Integer> {
    List<SpecialRequest> findSpecialRequests();
}