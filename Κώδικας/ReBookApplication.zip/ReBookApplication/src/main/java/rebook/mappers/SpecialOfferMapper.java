package rebook.mappers;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import rebook.domainmodel.Book;
import rebook.domainmodel.SpecialRequest;

@Repository
public interface SpecialOfferMapper  extends JpaRepository<SpecialRequest, Integer>{
	List<SpecialRequest> findSpecialOffer(String title);
	List<Book> findSpecialBook(String title);
	SpecialRequest saveSpecialOffer(Book book);
}
