package rebook.mappers;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import rebook.domainmodel.Book;
import rebook.domainmodel.BookAuthor;
import rebook.domainmodel.BookCategory;
import rebook.domainmodel.SimpleReader;

import java.util.List;

@Repository
public interface BookMapper extends JpaRepository<Book, Integer> {
    List<Book> findByTitle(String title); // Exact match assuming case and spacing must match exactly
    List<Book> findByTitleContaining(String title); // For containing specific text
    List<Book> findByOwner(SimpleReader owner);
    Book findByBookId(int bookId);
    
    // Find books by category
    List<Book> findByBookCategory(BookCategory category);
    
    // Find books by author
    List<Book> findByBookAuthorsContains(BookAuthor author);
    
    List<Book> findBookRead();
}