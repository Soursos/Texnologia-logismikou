package rebook.mappers;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import rebook.domainmodel.BulkOffer;
import rebook.domainmodel.SimpleReader;

@Repository
public interface LibraryMapper extends JpaRepository<SimpleReader, Integer> {
	List<BulkOffer> findBulkOffers(); 
}
