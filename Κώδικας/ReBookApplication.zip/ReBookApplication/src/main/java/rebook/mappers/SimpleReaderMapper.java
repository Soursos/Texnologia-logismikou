package rebook.mappers;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import rebook.domainmodel.Points;
import rebook.domainmodel.SimpleReader;
import rebook.domainmodel.Voucher;

@Repository
public interface SimpleReaderMapper extends JpaRepository<SimpleReader, Integer> {
	// for duplicate assignment
	boolean duplicateAssignment();
	void saveRating();
	Points findPoints();
	Voucher saveVoucher();
}
