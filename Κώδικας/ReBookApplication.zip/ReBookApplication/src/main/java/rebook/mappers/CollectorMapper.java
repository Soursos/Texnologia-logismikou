package rebook.mappers;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import rebook.domainmodel.SimpleReader;

@Repository
public interface CollectorMapper extends JpaRepository<SimpleReader, Integer> {
	// for duplicate assignment
	boolean duplicateAssignment();
	void saveRating();
}
