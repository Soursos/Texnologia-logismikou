package rebook.domainmodel;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

public class Voucher {
	@Id
    @Column(name = "voucher_id")
    @GeneratedValue(strategy=GenerationType.IDENTITY) 
    private int voucherId;
	
	@OneToOne()
    private Points points;
	
	@OneToOne()
    private SimpleReader simpleReader;
	
	
}
