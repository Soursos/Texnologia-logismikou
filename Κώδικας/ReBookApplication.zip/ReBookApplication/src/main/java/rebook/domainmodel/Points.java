package rebook.domainmodel;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

public class Points {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@JoinColumn(name = "points_id")
    private int pointsId;
	
	@OneToOne()
    private User user;
	
	@Column(name = "totalPoints", nullable = false, unique = true)
    private Integer totalPoints;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")   // ⬅ ADD THIS
    private LocalDate lastUpdated;
}
