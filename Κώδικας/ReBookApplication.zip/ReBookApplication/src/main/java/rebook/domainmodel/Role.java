package rebook.domainmodel;


public enum Role {
 USER 
}

