package rebook.services;

import java.util.List;
import java.util.Map;

import rebook.domainmodel.Book;
import rebook.domainmodel.Points;
import rebook.domainmodel.SpecialRequest;
import rebook.domainmodel.Voucher;
import rebook.formsdata.BookFormData;
import rebook.formsdata.RecommendationsFormData;
import rebook.formsdata.SearchFormData;
import rebook.formsdata.SimpleReaderFormData;

public interface SimpleReaderService {
	SimpleReaderFormData retrieveProfile(String username);
    void save(SimpleReaderFormData userProfileFormData);
    List<BookFormData> retrieveBookOffers(String username);
    void addBookOffer(String username, BookFormData bookFormData);
    List<BookFormData> searchBooks(String username,SearchFormData searchFormData);
    List<BookFormData> recommendBooks(String username, RecommendationsFormData recommendationsFormData);
    void requestBook(int bookId, String username);
    List<BookFormData> retrieveBookRequests(String username);
    List<SimpleReaderFormData> retrieveRequestingUsers(int bookId);
    void deleteBookOffer(String username, int bookId);
    void deleteBookRequest(String username, int acceptedprofileId, int bookId);
    Map<Integer, String> getAllCategories();
    
    // Implement
    boolean checkAvailability(int bookId);
    void stateOfRequest(int bookId);
    void sendEmail(String Username);
    List<BookFormData> retrieveCompletedTransactions();
    void submitRating();
    void addPoints();
    List<BookFormData> retrieveReadsReviews();
    void sortBooks();
    void saveReview();
    boolean checkReviewValidation();
    SpecialRequest retrieveSpecialOffer(String title);
    BookFormData retrieveSpecialBookInfo(String title);
    boolean checkSpecialOffer();
    void acceptSpecialOffer(Book book);
    void sendEmail();
    Integer retrieveAvailablePoints(Points points);
    void reedemPointsCheck();
    void createVoucher();
    void checkOlderCoupons(String username);
    void expiredVoucher(Voucher voucher);
}
