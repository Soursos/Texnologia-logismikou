package rebook.services;

import java.util.List;
import java.util.Map;

import rebook.formsdata.BookFormData;
import rebook.formsdata.RecommendationsFormData;
import rebook.formsdata.SearchFormData;
import rebook.formsdata.SimpleReaderFormData;

public interface LibraryService {
	SimpleReaderFormData retrieveProfile(String username);
    void save(SimpleReaderFormData userProfileFormData);
    List<BookFormData> retrieveBookOffers(String username);
    void addBookOffer(String username, BookFormData bookFormData);
    List<BookFormData> searchBooks(String username,SearchFormData searchFormData);
    List<BookFormData> recommendBooks(String username, RecommendationsFormData recommendationsFormData);
    void requestBook(int bookId, String username);
    List<BookFormData> retrieveBookRequests(String username);
    List<SimpleReaderFormData> retrieveRequestingUsers(int bookId);
    void deleteBookOffer(String username, int bookId);
    void deleteBookRequest(String username, int acceptedprofileId, int bookId);
    Map<Integer, String> getAllCategories();
    
    // Implement
    List<BookFormData> retrieveBulkkOffers();
    void addBulkOffer();
}
