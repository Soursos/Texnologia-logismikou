package rebook.strategy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import rebook.domainmodel.Book;
import rebook.domainmodel.BookAuthor;
import rebook.formsdata.SearchFormData;
import rebook.mappers.BookMapper;
import rebook.strategy.ApproximateSearchStrategy;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

class ApproximateSearchStrategyTest {

    @Mock
    private BookMapper bookMapper;

    @InjectMocks
    private ApproximateSearchStrategy strategy;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testMakeInitialListOfBooks() {
        SearchFormData searchFormData = new SearchFormData();
        searchFormData.setTitle("test");

        Book book1 = new Book();
        book1.setTitle("testBook");

        when(bookMapper.findByTitleContaining("test")).thenReturn(Arrays.asList(book1));

        List<Book> books = strategy.makeInitialListOfBooks(searchFormData);
        assertTrue(books.contains(book1));
        verify(bookMapper).findByTitleContaining("test");
    }

    @Test
    void testCheckIfAuthorsMatch() {
        SearchFormData searchFormData = new SearchFormData();
        searchFormData.setAuthorNames(Arrays.asList("Author One"));

        Book book = new Book();
        BookAuthor author = new BookAuthor();
        author.setAuthorName("Author One");
        book.setBookAuthors(Arrays.asList(author));

        assertTrue(strategy.checkIfAuthorsMatch(searchFormData, book));
    }
}
