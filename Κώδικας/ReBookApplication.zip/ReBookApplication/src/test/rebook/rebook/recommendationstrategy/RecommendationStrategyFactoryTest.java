package rebook.recommendationstrategy;


import org.junit.jupiter.api.Test;

import rebook.recommendationstrategy.AuthorBasedRecommendation;
import rebook.recommendationstrategy.CategoryBasedRecommendation;
import rebook.recommendationstrategy.CompositeRecommendation;
import rebook.recommendationstrategy.RecommendationStrategyFactory;

import static org.junit.jupiter.api.Assertions.*;

class RecommendationStrategyFactoryTest {

    @Test
    void testGetStrategyAuthor() {
        assertTrue(RecommendationStrategyFactory.getStrategy("AUTHOR") instanceof AuthorBasedRecommendation);
    }

    @Test
    void testGetStrategyCategory() {
        assertTrue(RecommendationStrategyFactory.getStrategy("CATEGORY") instanceof CategoryBasedRecommendation);
    }

    @Test
    void testGetStrategyComposite() {
        assertTrue(RecommendationStrategyFactory.getStrategy("COMPOSITE") instanceof CompositeRecommendation);
    }

    @Test
    void testGetStrategyInvalid() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            RecommendationStrategyFactory.getStrategy("NON_EXISTENT");
        });
        assertEquals("Unknown strategy type", exception.getMessage());
    }
}
