package rebook.mappers;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import rebook.domainmodel.SimpleReader;
import rebook.mappers.SimpleReaderMapper;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class UserProfileMapperTest {

    @Autowired
    private SimpleReaderMapper profileMapper;

    @Test
    public void testUserProfilePersistence() {
        SimpleReader userProfile = new SimpleReader();
        userProfile.setFullName("Test");
        userProfile = profileMapper.save(userProfile);
        assertNotNull(profileMapper.findById(userProfile.getProfileId()));
    }
}
